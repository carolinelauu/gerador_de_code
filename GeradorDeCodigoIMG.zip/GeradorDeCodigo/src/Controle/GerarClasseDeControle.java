package Controle;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import tools.ManipulaArquivo;
import tools.StringTools;

public class GerarClasseDeControle {

    public GerarClasseDeControle(String nomeDaClasse, List<String> atributo, String caminho) {
        StringTools st = new StringTools();
        String[] aux;
        List<String> cg = new ArrayList();//código gerado
        cg.add("package Controles;");

        cg.add("import Entidades." + nomeDaClasse + ";\n"
                + "import java.util.ArrayList;\n"
                + "import java.text.SimpleDateFormat;\n"
                + "import java.util.List;\n"
                + "import java.text.ParseException;\n"
                + "import tools.ManipulaArquivo;");
        cg.add("public class " + nomeDaClasse + "Controle {\n");
        cg.add(" private List<" + nomeDaClasse + "> lista = new ArrayList<>();");
        cg.add(" public " + nomeDaClasse + "Controle() {\n"
                + "    }");

        cg.add("""
                public void limparLista() {
                        lista.clear();//zera a lista
                    }""");
        cg.add(" public void adicionar(" + nomeDaClasse + " " + st.plMinus(nomeDaClasse) + ") {\n"
                + "        lista.add(" + st.plMinus(nomeDaClasse) + ");\n"
                + "    }");
        cg.add("public List<" + nomeDaClasse + "> listar() {\n"
                + "        return lista;\n"
                + "    }");

        aux = atributo.get(0).split(";");
        cg.add(" public " + nomeDaClasse + " buscar(" + aux[0] + " " + aux[1] + ") {\n"
                + "        for (int i = 0; i < lista.size(); i++) {\n");
        String s = switch (aux[0]) {
            case "int", "short", "double", "long", "float" -> "if (lista.get(i).get" + st.plMaiusc(aux[1]) + "() == " + aux[1] + ") {\n";
            case "String", "char" -> "if (lista.get(i).get" + st.plMaiusc(aux[1]) + "().equals(" + aux[1] + ")) {\n";
            default -> throw new AssertionError();
        };
        cg.add(s);

        cg.add("""
                            return lista.get(i);
                        }
                    }
                    return null;
                }""".indent(4));
        cg.add("public void alterar(" + nomeDaClasse + " " + st.plMinus(nomeDaClasse) + ", " + nomeDaClasse + " " + st.plMinus(nomeDaClasse) + "Antigo) {\n"
                + "        lista.set(lista.indexOf(" + st.plMinus(nomeDaClasse) + "Antigo), " + st.plMinus(nomeDaClasse) + ");\n"
                + "\n"
                + "    }");
        cg.add("public void excluir(" + nomeDaClasse + " " + st.plMinus(nomeDaClasse) + ") {\n"
                + "        lista.remove(" + st.plMinus(nomeDaClasse) + ");\n"
                + "    }");
        cg.add(" public void gravarLista(String caminho) {\n"
                + "        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();\n"
                + "        List<String> listaDeString = new ArrayList<>();\n"
                + "        for (" + nomeDaClasse + " " + st.plMinus(nomeDaClasse) + " : lista) {\n"
                + "            listaDeString.add(" + st.plMinus(nomeDaClasse) + ".toString()+System.lineSeparator());\n"
                + "        }\n"
                + "        manipulaArquivo.salvarArquivo(caminho, listaDeString);\n"
                + "    }");

        s = "";
        int w = 0;
        for (int i = 0; i < atributo.size(); i++) {

            aux = atributo.get(i).split(";");
            //   aux[i]=aux[i].trim();
            if ("Date".equals(aux[0])) {
                cg.add("SimpleDateFormat sdf"+i+" = new SimpleDateFormat(\"" + aux[2] + "\");");
                w++;
            }
            s = switch (aux[0]) {
                case "String" -> s + "aux[" + i + "], ";
                case "int" -> s + "Integer.parseInt(aux[" + i + "]), ";
                case "double" -> s + "Double.parseDouble(aux[" + i + "]), ";
                case "Date" -> s + "sdf"+i+".parse(aux[" + i + "]), ";
                case "Boolean" -> s + "Boolean.parseBoolean(aux[" + i + "]), ";
                case "long" -> s + "Long.parseLong(aux[" + i + "]), ";
                case "short" -> s + "Short.parseShort(aux[" + i + "]), ";
                case "float" -> s + "Float.parseFloat(aux[" + i + "]), ";
                case "char" -> s + "(aux[" + i + "]).charAt(0), ";
                default -> s;
            };
        }

        s = s.substring(0, s.length() - 2);
        cg.add("public void carregarDados(String caminho) {\n"
                + "        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();\n"
                + "        if (!manipulaArquivo.existeOArquivo(caminho)) {\n"
                + "            manipulaArquivo.criarArquivoVazio(caminho);\n"
                + "        }\n"
                + "\n"
                + "        List<String> listaDeString = manipulaArquivo.abrirArquivo(caminho);\n"
                + "        //converter de CSV para " + nomeDaClasse + "\n"
                + "        " + nomeDaClasse + " " + st.plMinus(nomeDaClasse) + " = null;\n"
                + "        for (String string : listaDeString) {\n"
                + "            String aux[] = string.split(\";\");\n");
                if (w>0){
                    cg.add("try {");
                    cg.add("" + st.plMinus(nomeDaClasse) + " = new " + nomeDaClasse + "(" + s + ");\n");
                    cg.add("} catch (ParseException e) {\n" +
                            "                e.printStackTrace();\n" +
                            "            }");
                } else{
                    cg.add("" + st.plMinus(nomeDaClasse) + " = new " + nomeDaClasse + "(" + s + ");\n");
                }
                cg.add("lista.add(" + st.plMinus(nomeDaClasse) + ");\n"
                + "        }\n"
                + "    }");
        cg.add("");
        cg.add("");

        cg.add("} //fim da classe");

        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        manipulaArquivo.salvarArquivo(caminho + "/src/Controles/" + nomeDaClasse + "Controle.java", cg);

    }

}

package Main;

import GUI.GUIdoGerador;

public class Main {
    public static void main(String[] args) {
        GUIdoGerador guiDoGerador = new GUIdoGerador();
    }
}
